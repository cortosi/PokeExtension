export class Machine {

    constructor(name, move, gen) {
        this._name = name
        this._move = move
        this._gen = gen
    }

    
}